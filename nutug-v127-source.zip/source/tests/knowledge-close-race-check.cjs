const assert = require('node:assert/strict');
const fs = require('node:fs');
const {JSDOM} = require('jsdom');
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
async function until(predicate, message) {
  for (let i = 0; i < 100; i++) { if (predicate()) return; await wait(10); }
  assert.fail(message);
}
(async () => {
  const w = new JSDOM(fs.readFileSync('dist/index.html', 'utf8'), {
    runScripts: 'outside-only', url: 'https://example.com/'
  }).window;
  const d = w.document, queuedCloses = [], errors = [];
  w.addEventListener('error', e => errors.push(e.message));
  w.fetch = async url => ({ok: true, json: async () => JSON.parse(fs.readFileSync('dist/' + url.split('?')[0], 'utf8'))});
  w.SVGElement.prototype.getBoundingClientRect = () => ({width: 390, height: 420});
  w.ResizeObserver = class { observe() {} };
  w.matchMedia = () => ({matches: true});
  w.Element.prototype.scrollIntoView = () => {};
  w.HTMLDialogElement.prototype.showModal = function () { this.open = true; };
  // Native close events run in a later task, not inside dialog.close().
  w.HTMLDialogElement.prototype.close = function () {
    if (!this.open) return;
    this.open = false;
    queuedCloses.push(() => this.dispatchEvent(new w.Event('close')));
  };
  const flushCloses = () => { while (queuedCloses.length) queuedCloses.shift()(); };
  const loader = new w.MutationObserver(records => {
    for (const record of records) for (const node of record.addedNodes) {
      if (node.tagName === 'SCRIPT' && node.src) {
        w.eval(fs.readFileSync('dist/' + new URL(node.src).pathname.slice(1), 'utf8'));
        node.dispatchEvent(new w.Event('load'));
      } else if (node.tagName === 'LINK' && node.rel === 'stylesheet') node.dispatchEvent(new w.Event('load'));
    }
  });
  loader.observe(d.head, {childList: true});
  w.eval(['mongolian-orthography.js', 'data.js', 'app.js', 'knowledge-store.js'].map(f => fs.readFileSync('dist/' + f, 'utf8')).join('\n'));
  let heldId = null, releaseArticle, failId = null;
  const byId = w.KnowledgeStore.prototype.byId;
  w.KnowledgeStore.prototype.byId = async function (id) {
    if (id === heldId) await new Promise(resolve => { releaseArticle = resolve; });
    if (id === failId) throw Error('simulated unavailable article');
    return byId.call(this, id);
  };
  w.eval(fs.readFileSync('dist/knowledge.js', 'utf8'));
  const reader = d.querySelector('#kb-reader'), close = d.querySelector('#kb-close');
  await until(() => d.querySelector('[data-article="ger-craft"]'), 'library ready');
  const clickArticle = id => d.querySelector(`[data-article="${id}"]`).click();
  const opened = id => reader.open && reader.dataset.article === id;
  clickArticle('tribal-alliances');
  await until(() => opened('tribal-alliances'), 'article A opens');
  close.click();
  assert.equal(w.location.hash, '', 'Close synchronously removes the dismissed article');
  clickArticle('ger-craft');
  await until(() => opened('ger-craft') && d.querySelector('.apd-demo') && d.querySelector('.aw-panel'), 'article B and its enhancements open');
  const demo = d.querySelector('.apd-demo'), words = d.querySelector('.aw-panel');
  flushCloses();
  assert.equal(w.location.hash, '#article=ger-craft');
  assert(opened('ger-craft'));
  assert.equal(d.querySelector('.apd-demo'), demo, 'old close must not destroy new demo');
  assert.equal(d.querySelector('.aw-panel'), words, 'old close must not destroy new definitions');

  close.click(); flushCloses(); clickArticle('tribal-alliances');
  await until(() => opened('tribal-alliances'), 'reopen A');
  close.click(); heldId = 'ger-craft'; clickArticle('ger-craft');
  await until(() => releaseArticle, 'B fetch is pending');
  flushCloses();
  assert.equal(w.location.hash, '#article=ger-craft', 'queued close must not clear a pending B request');
  heldId = null; releaseArticle();
  await until(() => opened('ger-craft'), 'pending B must not be invalidated by old close');

  const cancel = new w.Event('cancel', {cancelable: true}); reader.dispatchEvent(cancel);
  assert(cancel.defaultPrevented, 'Escape dismissal uses the same synchronous cleanup');
  assert(!reader.open); assert.equal(w.location.hash, '');
  clickArticle('tribal-alliances'); await until(() => opened('tribal-alliances'), 'reopen after Escape');
  flushCloses(); assert(opened('tribal-alliances')); assert.equal(w.location.hash, '#article=tribal-alliances');

  w.location.hash = 'article=missing-article';
  await until(() => !reader.open && d.activeElement === d.querySelector('#kb-status'), 'invalid deep link must dismiss stale prose and expose its status');
  flushCloses(); assert.equal(w.location.hash, '#article=missing-article');
  clickArticle('tribal-alliances'); await until(() => opened('tribal-alliances'), 'reopen before failed navigation');
  failId = 'ger-craft'; w.location.hash = 'article=ger-craft';
  await until(() => !reader.open && d.activeElement.textContent === 'ᠳᠠᠬᠢᠨ ᠣᠷᠣᠯᠳᠤᠬᠤ', 'failed article exposes reachable retry outside closed modal');
  flushCloses(); assert.equal(w.location.hash, '#article=ger-craft');
  failId = null; d.activeElement.click();
  await until(() => opened('ger-craft'), 'retry opens same article');
  assert.equal(w.location.hash, '#article=ger-craft');
  assert.deepEqual(errors, []);
  loader.disconnect(); w.close();
  console.log('PASS: native-queued Close/Escape, newer loaded and pending articles, enhancement preservation, invalid deep links and reachable load-error retry.');
})().catch(error => { console.error(error); process.exit(1); });
