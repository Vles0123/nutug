(async()=>{
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const {JSDOM}=require(process.env.JSDOM_PATH||'jsdom');
const source=fs.readFileSync('content/knowledge-data.js','utf8');
const data=vm.runInNewContext(source+';KNOWLEDGE');
assert(data.articles.length>=1500);
for(const f of fs.readdirSync('dist').filter(f=>/\.(js|html)$/.test(f)))assert(!/[\u1810-\u1819]/.test(fs.readFileSync('dist/'+f,'utf8')),f+' contains traditional numeric glyphs');
const a=data.articles.find(a=>a.id==='document-kazan-arithmetic-1837');assert(a.title.startsWith('1837 '));assert(a.body[0].includes('1837'));
const w=new JSDOM(fs.readFileSync('dist/index.html','utf8'),{runScripts:'outside-only',url:'https://example.com/#article='+a.id}).window;
w.SVGElement.prototype.getBoundingClientRect=()=>({width:390,height:420});w.ResizeObserver=class{observe(){}};w.matchMedia=()=>({matches:true});w.Element.prototype.scrollIntoView=()=>{};w.HTMLDialogElement.prototype.showModal=function(){this.open=true};w.HTMLDialogElement.prototype.close=function(){this.open=false};
w.fetch=async url=>({ok:true,json:async()=>JSON.parse(fs.readFileSync('dist/'+url.split('?')[0],'utf8'))});w.eval(['mongolian-orthography.js','data.js','app.js','knowledge-store.js','knowledge.js'].map(f=>fs.readFileSync('dist/'+f,'utf8')).join('\n'));
await new Promise(r=>setTimeout(r,100));const d=w.document;assert.equal(d.querySelector('#kb-reader-title .kb-numeral').textContent,'1837');assert.equal(d.querySelector('#kb-reader-copy .kb-numeral').textContent,'1837');assert.equal(d.querySelector('#kb-stats strong').textContent,String(data.articles.length));assert(Number(d.querySelectorAll('#kb-stats strong')[1].textContent)>=1471);
for(const n of d.querySelectorAll('.kb-numeral')){assert(/^[0-9]+(?:[.,][0-9]+)*$/.test(n.textContent));assert.equal(n.dir,'ltr')}
const q=d.getElementById('kb-query');q.value='1837';q.dispatchEvent(new w.Event('input'));await new Promise(r=>setTimeout(r,500));assert(d.querySelector('[data-article="'+a.id+'"]'));
for(const value of ['1271','1368','1624','2025'])assert(source.includes(value));
assert(/\.kb-numeral\{[^}]*writing-mode:horizontal-tb[^}]*white-space:nowrap/.test(fs.readFileSync('dist/knowledge.css','utf8')));
assert(!/[\u1810-\u1819]/.test(d.body.textContent));w.close();console.log('PASS: Arabic glyphs throughout authored pages, 1837 title/body/search, live corpus/source counts, intact LTR number runs, representative historical years.');

})().catch(e=>{console.error(e);process.exit(1)});
