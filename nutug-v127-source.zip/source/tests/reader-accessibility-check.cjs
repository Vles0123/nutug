const assert = require('node:assert/strict');
const fs = require('node:fs');
const {JSDOM} = require('jsdom');
for (const [file, selectors] of [
  ['index.html', ['#kb-reader-scroll']],
  ['tribes.html', ['#tl-reader-scroll']],
  ['tribes-mobile.html', ['#tl-reader-scroll', '#tl-reader-body']]
]) {
  const d = new JSDOM(fs.readFileSync('dist/' + file, 'utf8')).window.document;
  for (const selector of selectors) {
    const region = d.querySelector(selector);
    assert.equal(region.tabIndex, 0, `${file} ${selector}: keyboard must reach the reading scroll region`);
    assert.equal(region.getAttribute('role'), 'region');
    assert(d.getElementById(region.getAttribute('aria-labelledby')), 'reading region has an article-title label');
  }
}
const w = new JSDOM('<style>' + fs.readFileSync('dist/knowledge.css', 'utf8') + '</style><section id="knowledge"><button id="kb-previous">previous</button></section>').window;
const css = w.getComputedStyle(w.document.getElementById('kb-previous'));
function luminance(value) {
  const rgb = value.match(/[\d.]+/g).slice(0, 3).map(n => +n / 255).map(n => n <= .04045 ? n / 12.92 : ((n + .055) / 1.055) ** 2.4);
  return rgb[0] * .2126 + rgb[1] * .7152 + rgb[2] * .0722;
}
const values = [luminance(css.color), luminance(css.backgroundColor)].sort((a, b) => b - a);
const ratio = (values[0] + .05) / (values[1] + .05);
assert(ratio >= 4.5, `previous-page text contrast ${ratio.toFixed(2)} must be at least 4.5:1`);
for (const [file, selector] of [['knowledge.css', '.kb-reader-scroll:focus-visible'], ['tribes.css', '#tl-reader-body:focus-visible']]) {
  assert(fs.readFileSync('dist/' + file, 'utf8').includes(selector), 'keyboard reading focus stays visibly indicated');
}
assert(/@media\(max-width:600px\)\{[\s\S]*\.kb-card\{[^}]*overflow-x:auto;overflow-y:hidden/.test(fs.readFileSync('dist/knowledge.css', 'utf8')), 'narrow book covers expose overflowing title columns through horizontal scrolling');
w.close();
console.log(`PASS: four focusable, named reading regions, horizontally reachable narrow cover titles and previous-page contrast ${ratio.toFixed(2)}:1. Native browser scrolling is separate from DOM checks.`);
