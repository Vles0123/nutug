// The asynchronous chunked library regression suite replaces the old monolithic DOM suite.
require('./knowledge-scalable-check.cjs');
