// Rebuild map labels/summaries from the canonical article and person registries.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const data=JSON.parse(fs.readFileSync('content/history-map.json','utf8'));
const K=vm.runInNewContext(fs.readFileSync('content/knowledge-data.js','utf8')+';KNOWLEDGE');
const people=vm.runInNewContext(fs.readFileSync('dist/data.js','utf8')+';PEOPLE');
const articles=new Map(K.articles.map(a=>[a.id,a]));data.articles={};
for(const id of new Set([...data.stages.flatMap(s=>s.articleIds),...data.features.flatMap(f=>f.articleIds)])){assert(articles.has(id));const a=articles.get(id);data.articles[id]={id,title:a.title,summary:a.summary}}
for(const stage of data.stages){stage.people=stage.people.map(p=>{assert(people[p.id]);return {id:p.id,name:people[p.id].name}});for(const id of stage.featureIds)assert(data.features.some(f=>f.id===id));}
for(const feature of data.features)for(const id of feature.sourceIds)assert.equal(new URL(data.sources[id].url).protocol,'https:');
fs.writeFileSync('dist/history-map-data.json',JSON.stringify(data,null,2)+'\n');console.log(JSON.stringify({stages:data.stages.length,features:data.features.length,articles:Object.keys(data.articles).length}));
