const MongolianOrthography=require('../dist/mongolian-orthography.js');
const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),crypto=require('node:crypto');
const normalize=s=>MongolianOrthography.normalize(s.normalize('NFKC').toLowerCase()).replace(/[٠-٩۰-۹᠐-᠙]/g,c=>String(c.charCodeAt(0)-(c<='٩'?0x660:c<='۹'?0x6f0:0x1810)));
const hash=s=>{let h=2166136261;for(const c of s)h=Math.imul(h^c.codePointAt(0),16777619);return (h>>>0)%256};
function build(data,out){
 fs.mkdirSync(out,{recursive:true});const write=(name,value)=>fs.writeFileSync(path.join(out,name),JSON.stringify(value));
 const size=48,searchSize=256,categories={},related={},ids=Array.from({length:256},()=>({})),grams=Array.from({length:256},()=>({}));
 const sources=new Set(),search=[];
 for(let n=0;n<data.articles.length;n++){const a=data.articles[n];if(!a.id||!Array.isArray(a.body)||!a.sources?.length)throw Error('Invalid article '+n);(categories[a.category]??=[]).push(n);ids[hash(a.id)][a.id]=n;for(const p of a.relatedPeople||[])(related[p]??=[]).push(n);
 for(const s of a.sources){const u=new URL(s.url);u.hash='';u.hostname=u.hostname.replace(/^www\./,'');u.pathname=u.pathname.replace(/\/$/,'');for(const k of [...u.searchParams.keys()])if(k.startsWith('utm_')||k==='hl')u.searchParams.delete(k);u.searchParams.sort();if(u.hostname==='mongolbank.mn'&&['/mn/p/history','/mn/p/brief-history','/mn/r/history','/r/history'].includes(u.pathname))u.pathname='/mn/p/brief-history';sources.add(u.href)}
 const text=normalize([a.title,a.summary,...a.body].join(' '));search.push(text);const seen=new Set();for(let i=0;i<text.length-2;i++)seen.add(text.slice(i,i+3));for(const g of seen)(grams[hash(g)][g]??=[]).push(n);
 }
 if(new Set(data.articles.map(a=>a.id)).size!==data.articles.length)throw Error('Duplicate article IDs');
 for(let i=0;i<data.articles.length;i+=size)write('articles-'+i/size+'.json',data.articles.slice(i,i+size));
 for(let i=0;i<search.length;i+=searchSize)write('search-'+i/searchSize+'.json',search.slice(i,i+searchSize));
 for(let i=0;i<256;i++){for(const [g,list] of Object.entries(grams[i])){let previous=0;const bytes=[];for(const n of list){let delta=n-previous;previous=n;while(delta>=128){bytes.push((delta&127)|128);delta>>>=7}bytes.push(delta)}grams[i][g]=[list.length,Buffer.from(bytes).toString('base64')]}write('grams-'+i+'.json',grams[i]);write('ids-'+i+'.json',ids[i])}
 const {articles,...meta}=data;const manifest={...meta,format:1,total:articles.length,sourceCount:sources.size,chunkSize:size,searchSize,categories,related,revision:crypto.createHash('sha256').update(JSON.stringify(data)).digest('hex').slice(0,16)};write('manifest.json',manifest);return manifest;
}
module.exports={build,hash,normalize};if(require.main===module){const data=vm.runInNewContext(fs.readFileSync('content/knowledge-data.js','utf8')+';KNOWLEDGE');console.log(JSON.stringify(build(data,'dist/knowledge')));require('./audit-mongolian-shaping.cjs').writeReport()}
