"""Shape map label words intact with the bundled font, retaining all variation controls."""
import json
import uharfbuzz as hb
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.boundsPen import BoundsPen
fontpath='dist/fonts/NotoSansMongolian-Regular.ttf'
font=TTFont(fontpath);glyphs=font.getGlyphSet();face=hb.Face(open(fontpath,'rb').read());hf=hb.Font(face);hf.scale=(face.upem,face.upem)
def outline(text):
 b=hb.Buffer();b.add_str(text);b.direction='ltr';b.script='Mong';b.language='mn';hb.shape(hf,b)
 pen=SVGPathPen(glyphs);bp=BoundsPen(glyphs);x=y=0
 for g,pos in zip(b.glyph_infos,b.glyph_positions):
  glyph=glyphs[font.getGlyphName(g.codepoint)];transform=(1,0,0,1,x+pos.x_offset,y+pos.y_offset)
  glyph.draw(TransformPen(pen,transform));glyph.draw(TransformPen(bp,transform));x+=pos.x_advance;y+=pos.y_advance
 return {'label':text,'path':pen.getCommands(),'bounds':bp.bounds,'advance':x,'upem':face.upem}
labels={}
for feature in json.load(open('content/history-map.json'))['features']:
 item=outline(feature['labelMn'])
 if feature.get('mapLabelMn'):
  item['mapLabel']=feature['mapLabelMn']
  item['words']=[outline(word) for word in feature['mapLabelMn'].split(' ')]
 labels[feature['id']]=item
json.dump(labels,open('dist/map/place-labels.json','w'),ensure_ascii=False,separators=(',',':'))
print(json.dumps({'mapLabels':len(labels)}))
