const fs = require('node:fs');
const {spawnSync} = require('node:child_process');
const files = fs.readdirSync('tests').filter(f => f.endsWith('-check.cjs')).sort();
for (const file of files) {
  console.log('\n=== ' + file + ' ===');
  const result = spawnSync(process.execPath, ['tests/' + file], {stdio: 'inherit'});
  if (result.status !== 0) process.exit(result.status || 1);
}
console.log('\nPassed ' + files.length + ' regression checks.');
