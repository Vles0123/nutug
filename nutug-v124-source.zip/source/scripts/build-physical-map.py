"""Clip official Natural Earth 10m physical vectors; never derive political boundaries."""
import os,sys,json,hashlib,zipfile
import shapefile
from shapely.geometry import shape,box,mapping
from shapely import make_valid
RAW=os.environ.get('NATURAL_EARTH_RAW','.cache/natural-earth')
BOUNDS=[84,36,130,57];W,H,P=1000,682,30
clip=box(*BOUNDS)
def project(x,y):return (P+(x-BOUNDS[0])/(BOUNDS[2]-BOUNDS[0])*(W-2*P),P+(BOUNDS[3]-y)/(BOUNDS[3]-BOUNDS[1])*(H-2*P))
def line(coords,close=False):
 pts=[project(x,y) for x,y,*_ in coords]
 return ('M'+'L'.join(f'{x:.2f},{y:.2f}' for x,y in pts)+('Z' if close else '')) if pts else ''
def path(g):
 if g.is_empty:return ''
 if g.geom_type=='Polygon':return line(g.exterior.coords,True)+''.join(line(r.coords,True) for r in g.interiors)
 if g.geom_type in ('LineString','LinearRing'):return line(g.coords)
 if hasattr(g,'geoms'):return ''.join(path(a) for a in g.geoms)
 return ''
def records(layer):
 folder=f'{RAW}/{layer}';archive=f'{RAW}/ne_10m_{layer}.zip'
 if not os.path.exists(folder):
  with zipfile.ZipFile(archive) as z:z.extractall(folder)
 reader=shapefile.Reader(f'{folder}/ne_10m_{layer}.shp')
 for sr in reader.iterShapeRecords():
  if not box(*sr.shape.bbox).intersects(clip):continue
  d=sr.record.as_dict();g=make_valid(shape(sr.shape.__geo_interface__)).intersection(clip).simplify(.015,preserve_topology=True)
  if not g.is_empty:yield d,g
layers={};stats={}
for layer in ['land','lakes','rivers_lake_centerlines']:
 result=[]
 for d,g in records(layer):
  feature=d.get('featurecla','')
  if layer=='lakes' and feature not in ('Lake','Alkaline Lake'):continue
  if layer.startswith('rivers') and feature not in ('River','River (Intermittent)'):continue
  result.append({'name':d.get('name') or '', 'featureClass':feature,'rank':d.get('scalerank',0),'path':path(g)})
 layers[layer]=result;stats[layer]=len(result)
sources=[]
for layer in layers:
 name=f'ne_10m_{layer}';archive=f'{RAW}/{name}.zip';version=open(f'{RAW}/{layer}/{name}.VERSION.txt').read().strip()
 sources.append({'dataset':name,'version':version,'url':f'https://naciscdn.org/naturalearth/10m/physical/{name}.zip','sha256':hashlib.sha256(open(archive,'rb').read()).hexdigest()})
out={'bounds':BOUNDS,'width':W,'height':H,'padding':P,'projection':'Equirectangular regional reference; all overlays use identical transform','reference':'Modern physical geography for orientation, not reconstructed medieval shorelines or channels','license':'Public domain','licenseUrl':'https://www.naturalearthdata.com/about/terms-of-use/','sources':sources,'layers':layers}
with open('dist/map/physical-geography.json','w') as f:json.dump(out,f,separators=(',',':'))
svg=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">',f'<rect width="{W}" height="{H}" fill="#e7e5cc"/><rect x="{P}" y="{P}" width="{W-2*P}" height="{H-2*P}" fill="#9fcbd4"/>']
for layer in layers:
 for item in layers[layer]:
  if layer=='land':style='fill="#e7e5cc" fill-rule="evenodd"'
  elif layer=='lakes':style='fill="#94c7d2" stroke="#609ba9" stroke-width="1.2" fill-rule="evenodd"'
  else:style='fill="none" stroke="#68a4b5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"'
  svg.append(f'<path d="{item["path"]}" {style}/>')
svg.append('</svg>');open('dist/map/physical-geography.svg','w').write(''.join(svg))
print(json.dumps({'bounds':BOUNDS,'layers':stats,'jsonBytes':os.path.getsize('dist/map/physical-geography.json'),'svgBytes':os.path.getsize('dist/map/physical-geography.svg'),'baikal':any('Baikal' in r['name'] for r in layers['lakes'])}))

# Preserve complete-word shaping for the selected place label in the final SVG.
import uharfbuzz as hb
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.boundsPen import BoundsPen
fontpath='dist/fonts/NotoSansMongolian-Regular.ttf';font=TTFont(fontpath);glyphs=font.getGlyphSet();face=hb.Face(open(fontpath,'rb').read());hf=hb.Font(face);hf.scale=(face.upem,face.upem)
labels={}
for feature in json.load(open('content/history-map.json'))['features']:
 b=hb.Buffer();b.add_str(feature['labelMn']);b.direction='ltr';b.script='Mong';b.language='mn';hb.shape(hf,b)
 pen=SVGPathPen(glyphs);bp=BoundsPen(glyphs);x=y=0
 for g,pos in zip(b.glyph_infos,b.glyph_positions):
  glyph=glyphs[font.getGlyphName(g.codepoint)];transform=(1,0,0,1,x+pos.x_offset,y+pos.y_offset);glyph.draw(TransformPen(pen,transform));glyph.draw(TransformPen(bp,transform));x+=pos.x_advance;y+=pos.y_advance
 labels[feature['id']]={'label':feature['labelMn'],'path':pen.getCommands(),'bounds':bp.bounds,'advance':x,'upem':face.upem}
json.dump(labels,open('dist/map/place-labels.json','w'),ensure_ascii=False,separators=(',',':'))
